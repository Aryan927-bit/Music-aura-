package com.musicaura

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.audiofx.Visualizer
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * Equalizer bars. Tries the real system audio (Visualizer API, needs mic permission);
 * if the phone/app blocks it, falls back to an animated simulation while music plays.
 */
class VisualizerView(ctx: Context) : View(ctx) {
    private val bars = 32
    private val level = FloatArray(bars)
    private val target = FloatArray(bars)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var viz: Visualizer? = null
    private var real = false
    private var t = 0f
    var color = Color.WHITE

    private val tick = object : Runnable {
        override fun run() { step(); invalidate(); postOnAnimation(this) }
    }

    fun start() {
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try {
                viz = Visualizer(0).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1]
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {}
                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray, r: Int) = onFft(fft)
                    }, Visualizer.getMaxCaptureRate() / 2, false, true)
                    enabled = true
                }
                real = true
            } catch (_: Exception) { real = false }
        }
        postOnAnimation(tick)
    }

    fun stop() {
        removeCallbacks(tick)
        try { viz?.enabled = false; viz?.release() } catch (_: Exception) {}
        viz = null
    }

    private fun onFft(fft: ByteArray) {
        val n = fft.size / 2
        for (i in 0 until bars) {
            val a = 1 + ((i / bars.toFloat()).pow(2f) * (n * 0.6f)).toInt()
            val b = maxOf(a + 1, 1 + (((i + 1) / bars.toFloat()).pow(2f) * (n * 0.6f)).toInt())
            var m = 0f
            for (k in a until minOf(b, n)) m = maxOf(m, hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat()))
            target[i] = (m / 90f * (1f + i / 24f)).coerceIn(0f, 1f)
        }
    }

    private fun step() {
        t += 0.08f
        if (!real) {
            for (i in 0 until bars) {
                target[i] = if (MusicState.playing)
                    (0.25f + 0.6f * abs(sin(t * (1.2f + i % 5 * 0.35f) + i * 0.7f))) * (1f - i / 60f)
                else 0f
            }
        }
        for (i in 0 until bars) {
            val k = if (target[i] > level[i]) 0.45f else 0.12f
            level[i] += (target[i] - level[i]) * k
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val slot = w / bars; val bw = slot * 0.6f
        paint.color = color
        for (i in 0 until bars) {
            val bh = maxOf(h * 0.06f, level[i] * h)
            val x = i * slot + (slot - bw) / 2
            rect.set(x, h - bh, x + bw, h)
            c.drawRoundRect(rect, bw / 2, bw / 2, paint)
        }
    }
}
