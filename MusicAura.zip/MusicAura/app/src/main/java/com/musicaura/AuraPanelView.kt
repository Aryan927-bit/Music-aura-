package com.musicaura

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import kotlin.math.cos
import kotlin.math.sin

/** Full-screen glass "control center" that re-themes itself to the playing song. */
class AuraPanelView(ctx: Context, private val onClose: () -> Unit) :
    FrameLayout(ctx), SensorEventListener {

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var c1 = MusicState.c1
    private var c2 = MusicState.c2
    private var phase = 0f
    private var tx = 0f
    private var ty = 0f

    private val card = LinearLayout(ctx)
    private val art = ImageView(ctx)
    private val disc = FrameLayout(ctx)
    private val groove = GrooveView(ctx)
    private val hole = View(ctx)
    private val viz = VisualizerView(ctx)
    private val video = VideoBackground(ctx)
    private val scrim = View(ctx)
    private var vinyl = true
    private var spin: ObjectAnimator? = null
    private val title = TextView(ctx)
    private val artist = TextView(ctx)
    private val play = TextView(ctx)
    private val tiles = mutableListOf<TextView>()
    private val sensors = ctx.getSystemService(SensorManager::class.java)
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val listener: () -> Unit = { refresh() }
    private var colorAnim: ValueAnimator? = null
    private var torchOn = false

    private val drift = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 14000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedFraction; invalidate() }
    }

    private fun glass(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0x55FFFFFF)
    }

    private fun label(tv: TextView, sp: Float, bold: Boolean, color: Int) = tv.apply {
        textSize = sp; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
    }

    init {
        setWillNotDraw(false)
        setOnClickListener { onClose() }

        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.setPadding(dp(22), dp(26), dp(22), dp(22))
        card.elevation = dp(24).toFloat()
        card.cameraDistance = 9000f * d
        card.background = glass(0x26FFFFFF, 28)
        card.setOnClickListener { }

        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.elevation = dp(20).toFloat()
        art.clipToOutline = true
        art.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) =
                o.setRoundRect(0, 0, v.width, v.height, if (vinyl) v.width / 2f else dp(24).toFloat())
        }
        disc.addView(art, FrameLayout.LayoutParams(-1, -1))
        disc.addView(groove, FrameLayout.LayoutParams(-1, -1))
        hole.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(0xFF111111.toInt()); setStroke(dp(3), 0xCCFFFFFF.toInt())
        }
        disc.addView(hole, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        disc.setOnClickListener { vinyl = !vinyl; art.invalidateOutline(); refresh() }  // tap = vinyl / square
        card.addView(disc, LinearLayout.LayoutParams(dp(240), dp(240)).apply { bottomMargin = dp(20) })

        card.addView(label(title, 22f, true, Color.WHITE), LinearLayout.LayoutParams(-1, -2))
        card.addView(label(artist, 15f, false, 0xCCFFFFFF.toInt()), LinearLayout.LayoutParams(-1, -2))

        val controls = LinearLayout(context).apply { gravity = Gravity.CENTER }
        fun btn(tv: TextView, text: String, action: () -> Unit) {
            tv.text = text; tv.textSize = 34f; tv.setTextColor(Color.WHITE)
            tv.setPadding(dp(18), dp(10), dp(18), dp(10)); tv.setOnClickListener { action() }
            controls.addView(tv)
        }
        btn(TextView(context), "⏮") { MusicState.controller?.transportControls?.skipToPrevious() }
        btn(play, "▶") {
            val c = MusicState.controller ?: return@btn
            if (MusicState.playing) c.transportControls.pause() else c.transportControls.play()
        }
        btn(TextView(context), "⏭") { MusicState.controller?.transportControls?.skipToNext() }
        card.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val vol = SeekBar(context).apply {
            max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        card.addView(vol, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(14) })

        card.addView(viz, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(10) })

        val row = LinearLayout(context)
        fun tile(text: String, action: () -> Unit) {
            val tv = TextView(context).apply {
                this.text = text; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14)); setOnClickListener { action() }
            }
            tiles += tv
            row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        tile("📶\nInternet") { open(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        tile("🔵\nBluetooth") { open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        tile("🔦\nTorch") { toggleTorch() }
        tile("☀️\nDisplay") { open(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        card.addView(row, LinearLayout.LayoutParams(-1, -2))

addView(video, LayoutParams(-1, -1))
        addView(scrim, LayoutParams(-1, -1))
        addView(card, LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(dp(18), 0, dp(18), 0) })
    }

    private fun open(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(i) } catch (_: Exception) {}
        onClose()
    }

    private fun toggleTorch() {
        try {
            val cm = context.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (_: Exception) {}
    }

    private fun refresh() {
        title.text = MusicState.title.ifEmpty { "Nothing playing" }
        artist.text = MusicState.artist.ifEmpty { "Play a song in any app" }
        val bmp = MusicState.art
        if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(ColorDrawable(0x33FFFFFF))
        play.text = if (MusicState.playing) "⏸" else "▶"
        hole.visibility = if (vinyl) View.VISIBLE else View.GONE
        groove.visibility = if (vinyl) View.VISIBLE else View.GONE
        viz.color = MusicState.accent
        if (vinyl && MusicState.playing) {
            val s = spin ?: ObjectAnimator.ofFloat(art, "rotation", 0f, 360f).apply {
                duration = 9000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            }.also { spin = it }
            if (!s.isStarted) s.start() else if (s.isPaused) s.resume()
        } else if (vinyl) {
            spin?.pause()
        } else {
            spin?.cancel(); spin = null; art.rotation = 0f
        }

        val from1 = c1; val from2 = c2
        val to1 = MusicState.c1; val to2 = MusicState.c2
        colorAnim?.cancel()
        colorAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800
            addUpdateListener {
                val f = it.animatedFraction
                c1 = ArgbEvaluator().evaluate(f, from1, to1) as Int
                c2 = ArgbEvaluator().evaluate(f, from2, to2) as Int
                invalidate()
            }
            start()
        }
        tiles.forEach { it.background = glass(alpha(to1, 0x66), 18) }
        card.background = glass(alpha(to1, 0x33), 28)
        scrim.visibility = if (video.enabled) View.VISIBLE else View.GONE
        scrim.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(alpha(to1, 0x66), alpha(to2, 0xD0)))
        video.sync()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        paint.shader = LinearGradient(0f, 0f, w * 0.3f, h, c2, Color.BLACK, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        val a = phase * 6.2832f
        paint.shader = RadialGradient(
            w * (0.5f + 0.3f * sin(a)) + tx * w * 0.15f, h * (0.30f + 0.08f * cos(a)) + ty * h * 0.08f,
            w * 0.95f, alpha(c1, 210), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(
            w * (0.5f - 0.35f * sin(a)), h * (0.85f - 0.08f * cos(a)),
            w * 0.8f, alpha(MusicState.accent, 90), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val nx = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
        val ny = (e.values[1] / 9.8f - 0.6f).coerceIn(-1f, 1f)
        tx += (nx - tx) * 0.12f; ty += (ny - ty) * 0.12f
        card.rotationY = tx * 14f          // flip the sign if the tilt feels inverted
        card.rotationX = ty * 14f
        art.translationX = tx * dp(12); art.translationY = ty * dp(10)
        title.translationX = tx * dp(5)
        invalidate()
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MusicState.listeners.add(listener)
        refresh(); drift.start(); viz.start()
        sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        alpha = 0f; card.scaleX = 0.88f; card.scaleY = 0.88f
        animate().alpha(1f).setDuration(220).start()
        card.animate().scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(OvershootInterpolator()).start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        MusicState.listeners.remove(listener)
        drift.cancel(); colorAnim?.cancel(); spin?.cancel(); spin = null; viz.stop(); video.release(); sensors.unregisterListener(this)
    }
}

/** Faint concentric vinyl grooves. */
private class GrooveView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f; color = 0x26000000
    }
    override fun onDraw(cv: Canvas) {
        val r = width / 2f
        var x = r * 0.28f
        while (x < r - 4f) { cv.drawCircle(r, r, x, p); x += r * 0.09f }
    }
}
