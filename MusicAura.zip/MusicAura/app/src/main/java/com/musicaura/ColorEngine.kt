package com.musicaura

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.provider.Settings
import androidx.palette.graphics.Palette

object ColorEngine {
    fun extract(src: Bitmap) {
        val bmp = Bitmap.createScaledBitmap(src, 128, 128, true)
        val p = Palette.from(bmp).maximumColorCount(16).generate()
        val main = p.getVibrantColor(p.getDominantColor(0xFF6C5CE7.toInt()))
        MusicState.c1 = main
        MusicState.c2 = p.getDarkMutedColor(shade(main, 0.35f))
        MusicState.accent = p.getLightVibrantColor(Color.WHITE)
    }

    fun shade(c: Int, v: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv); hsv[2] *= v
        return Color.HSVToColor(hsv)
    }

    /** Experimental: needs `pm grant com.musicaura android.permission.WRITE_SECURE_SETTINGS`. */
    fun applySystemAccent(ctx: Context, color: Int) {
        try {
            val hex = String.format("%06X", color and 0xFFFFFF)
            val json = """{"android.theme.customization.system_palette":"$hex","android.theme.customization.accent_color":"$hex","android.theme.customization.color_source":"preset"}"""
            Settings.Secure.putString(ctx.contentResolver, "theme_customization_overlay_packages", json)
        } catch (_: Exception) { /* permission missing or ROM ignores it */ }
    }
}
