package com.musicaura

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.media.session.PlaybackState
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.webkit.WebView
import android.widget.FrameLayout
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Plays the current song's music video (muted) full-screen behind the panel.
 * Other apps never expose their video, so we look the song up on YouTube and sync to its position.
 */
@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
class VideoBackground(ctx: Context) : FrameLayout(ctx) {
    private val web = WebView(ctx)
    private val prefs = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
    private var key = ""
    private var wasPlaying = false

    val enabled: Boolean
        get() = prefs.getBoolean("videoBg", false) && !prefs.getString("ytKey", "").isNullOrBlank()

    init {
        isClickable = true                       // taps on the video close the panel (parent click)
        setOnClickListener { (parent as? View)?.performClick() }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.setBackgroundColor(Color.BLACK)
        web.loadDataWithBaseURL("https://www.youtube.com", HTML, "text/html", "utf-8", null)
        addView(web, LayoutParams(-1, -1))
        alpha = 0f
    }

    override fun onInterceptTouchEvent(e: MotionEvent) = true

    private fun js(code: String) = web.evaluateJavascript(code, null)

    private fun pos(): Int {
        val s = MusicState.controller?.playbackState ?: return 0
        var p = s.position
        if (s.state == PlaybackState.STATE_PLAYING)
            p += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
        return (p / 1000).toInt().coerceAtLeast(0)
    }

    /** Call whenever the music state changes. */
    fun sync() {
        if (!enabled) { visibility = GONE; return }
        visibility = VISIBLE
        if (MusicState.title.isEmpty()) {
            key = ""; animate().alpha(0f).setDuration(300).start(); js("setPlaying(false)"); return
        }
        val k = MusicState.title + "|" + MusicState.artist
        if (k != key) {
            key = k; wasPlaying = MusicState.playing
            animate().alpha(0f).setDuration(250).start()
            val q = "${MusicState.title} ${MusicState.artist} official video"
            val apiKey = prefs.getString("ytKey", "") ?: ""
            Thread {
                val id = synchronized(cache) {
                    if (cache.containsKey(q)) cache[q]
                    else (try { search(q, apiKey) } catch (_: Exception) { null }).also { if (it != null) cache[q] = it }
                }
                post {
                    if (k == key && id != null && id.matches(Regex("[A-Za-z0-9_-]{6,15}"))) {
                        js("loadVideo('$id',${pos()})")
                        postDelayed({ js("setPlaying(${MusicState.playing})") }, 1500)
                        animate().alpha(1f).setDuration(700).start()
                    }
                }
            }.start()
        } else if (MusicState.playing != wasPlaying) {
            wasPlaying = MusicState.playing
            if (MusicState.playing) js("seekTo(${pos()})")
            js("setPlaying(${MusicState.playing})")
        }
    }

    fun release() {
        removeAllViews()
        web.destroy()
    }

    private fun search(q: String, apiKey: String): String? {
        val url = URL("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
            "&videoEmbeddable=true&maxResults=1&q=${URLEncoder.encode(q, "UTF-8")}&key=$apiKey")
        val con = url.openConnection() as HttpURLConnection
        con.connectTimeout = 8000; con.readTimeout = 8000
        val body = con.inputStream.bufferedReader().readText()
        return JSONObject(body).getJSONArray("items").optJSONObject(0)?.getJSONObject("id")?.getString("videoId")
    }

    companion object {
        private val cache = HashMap<String, String>()
        private const val HTML = """<html><body style="margin:0;background:#000;overflow:hidden">
<div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var player, ready=false, pending=null;
function layout(){var W=innerWidth,H=innerHeight,s=Math.max(W/16,H/9),w=16*s,h=9*s,f=document.getElementById('p');
 f.style.position='absolute';f.style.width=w+'px';f.style.height=h+'px';f.style.left=(W-w)/2+'px';f.style.top=(H-h)/2+'px';f.style.pointerEvents='none';}
function onYouTubeIframeAPIReady(){player=new YT.Player('p',{playerVars:{controls:0,disablekb:1,fs:0,modestbranding:1,playsinline:1,rel:0,iv_load_policy:3,mute:1,autoplay:1},
 events:{onReady:function(){ready=true;player.mute();layout();if(pending)pending();},
 onStateChange:function(e){if(e.data===0){player.seekTo(0);player.playVideo();}}}});}
function loadVideo(id,start){var f=function(){player.mute();player.loadVideoById({videoId:id,startSeconds:start});layout();};if(ready)f();else pending=f;}
function seekTo(s){if(ready)player.seekTo(s,true);}
function setPlaying(p){if(!ready)return;if(p)player.playVideo();else player.pauseVideo();}
addEventListener('resize',layout);
</script></body></html>"""
    }
}
