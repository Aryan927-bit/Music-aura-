package com.musicaura

import android.app.WallpaperManager
import android.content.Context
import android.graphics.*

/** Paints a song-colored wallpaper onto the LOCK SCREEN only. */
object LockTint {
    private var last = 0L

    fun apply(ctx: Context, art: Bitmap?) {
        val now = System.currentTimeMillis()
        if (now - last < 4000) return
        last = now
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        val c1 = MusicState.c1; val c2 = MusicState.c2; val acc = MusicState.accent
        val app = ctx.applicationContext
        Thread {
            try {
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val cv = Canvas(bmp)
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                val wf = w.toFloat(); val hf = h.toFloat()
                p.shader = LinearGradient(0f, 0f, wf * 0.3f, hf, c2, Color.BLACK, Shader.TileMode.CLAMP)
                cv.drawRect(0f, 0f, wf, hf, p)
                if (art != null) {  // heavily stretched tiny copy = cheap blur
                    val tiny = Bitmap.createScaledBitmap(art, 24, 24, true)
                    val bp = Paint().apply { isFilterBitmap = true; alpha = 90 }
                    cv.drawBitmap(tiny, null, Rect(0, 0, w, h), bp)
                }
                p.shader = RadialGradient(wf * 0.3f, hf * 0.28f, wf, (c1 and 0xFFFFFF) or (0xB0 shl 24),
                    Color.TRANSPARENT, Shader.TileMode.CLAMP)
                cv.drawRect(0f, 0f, wf, hf, p)
                p.shader = RadialGradient(wf * 0.75f, hf * 0.85f, wf * 0.8f, (acc and 0xFFFFFF) or (0x70 shl 24),
                    Color.TRANSPARENT, Shader.TileMode.CLAMP)
                cv.drawRect(0f, 0f, wf, hf, p)
                WallpaperManager.getInstance(app).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
            } catch (_: Exception) {}
        }.start()
    }
}
