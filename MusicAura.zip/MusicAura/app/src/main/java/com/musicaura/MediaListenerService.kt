package com.musicaura

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService

/** Reads "now playing" from ANY app (Spotify, YouTube, Poweramp...) via media sessions. */
class MediaListenerService : NotificationListenerService() {
    private var msm: MediaSessionManager? = null
    private var current: MediaController? = null
    private var lastKey = ""

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = update()
        override fun onPlaybackStateChanged(state: PlaybackState?) = update()
    }
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    override fun onListenerConnected() {
        val cn = ComponentName(this, MediaListenerService::class.java)
        msm = getSystemService(MediaSessionManager::class.java).also {
            it.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(it.getActiveSessions(cn))
        }
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        current?.unregisterCallback(callback)
    }

    private fun pick(list: List<MediaController>?) {
        current?.unregisterCallback(callback)
        current = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        current?.registerCallback(callback)
        MusicState.controller = current
        update()
    }

    private fun update() {
        val c = current
        val m = c?.metadata
        MusicState.playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        MusicState.title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        MusicState.artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        MusicState.art = bmp

        val key = MusicState.title + MusicState.artist + (bmp?.generationId ?: 0)
        if (bmp != null && key != lastKey) {
            lastKey = key
            ColorEngine.extract(bmp)
            val prefs = getSharedPreferences("aura", MODE_PRIVATE)
            if (prefs.getBoolean("systemTint", false)) ColorEngine.applySystemAccent(this, MusicState.c1)
            if (prefs.getBoolean("lockTint", false)) LockTint.apply(this, bmp)
        }
        MusicState.notifyChanged()
    }
}
