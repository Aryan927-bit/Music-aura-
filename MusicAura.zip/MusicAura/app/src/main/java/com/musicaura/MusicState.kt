package com.musicaura

import android.graphics.Bitmap
import android.media.session.MediaController

/** Shared "now playing" state. Touched on the main thread only. */
object MusicState {
    var title = ""
    var artist = ""
    var art: Bitmap? = null
    var playing = false
    var controller: MediaController? = null

    var c1 = 0xFF6C5CE7.toInt()   // main vibrant color
    var c2 = 0xFF1B1464.toInt()   // dark background color
    var accent = 0xFFFFFFFF.toInt()

    val listeners = mutableListOf<() -> Unit>()
    fun notifyChanged() = listeners.toList().forEach { it() }
}
