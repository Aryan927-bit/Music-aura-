package com.musicaura

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad); gravity = Gravity.CENTER_HORIZONTAL
        }
        fun text(t: String, sp: Float) = TextView(this).apply { text = t; textSize = sp; setPadding(0, 0, 0, pad / 2) }
        fun button(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

        root.addView(text("Music Aura", 28f))
        root.addView(text("Do the 3 steps below once, then tap the floating bubble while music plays.", 14f))
        root.addView(button("1. Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("3. Start Music Aura") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(perms.toTypedArray(), 1)
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, PanelService::class.java))
        })
        root.addView(button("Battery: set to Unrestricted (Oppo)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(Switch(this).apply {
            text = "Also tint system accent (needs ADB, experimental)"
            val prefs = getSharedPreferences("aura", MODE_PRIVATE)
            isChecked = prefs.getBoolean("systemTint", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("systemTint", on).apply() }
        })
        root.addView(Switch(this).apply {
            text = "Tint LOCK SCREEN wallpaper to the song"
            val prefs = getSharedPreferences("aura", MODE_PRIVATE)
            isChecked = prefs.getBoolean("lockTint", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("lockTint", on).apply() }
        })
        root.addView(Switch(this).apply {
            text = "Play the song's music video in the panel background"
            val prefs = getSharedPreferences("aura", MODE_PRIVATE)
            isChecked = prefs.getBoolean("videoBg", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("videoBg", on).apply() }
        })
        val keyBox = EditText(this).apply {
            hint = "YouTube Data API key"; setSingleLine()
            setText(getSharedPreferences("aura", MODE_PRIVATE).getString("ytKey", ""))
        }
        root.addView(keyBox)
        root.addView(button("Save API key") {
            getSharedPreferences("aura", MODE_PRIVATE).edit().putString("ytKey", keyBox.text.toString().trim()).apply()
        })
        setContentView(root)
    }
}
