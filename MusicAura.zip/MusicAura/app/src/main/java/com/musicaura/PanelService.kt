package com.musicaura

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/** Keeps a small floating bubble (tinted to the song) that opens the Aura panel. */
class PanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: AuraPanelView? = null
    private val tint: () -> Unit = { bubble?.background = circle() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("aura", "Music Aura", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "aura")
            .setContentTitle("Music Aura is active").setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        addBubble()
        MusicState.listeners.add(tint)
    }

    private fun circle() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(MusicState.c1); setStroke(3, 0xAAFFFFFF.toInt())
    }

    private fun addBubble() {
        val size = (46 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val v = View(this).apply {
            background = circle(); elevation = 12f
            var startY = 0f; var startParamY = 0; var moved = false
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { startY = e.rawY; startParamY = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = (e.rawY - startY).toInt()
                        if (Math.abs(dy) > 12) moved = true
                        if (moved) { lp.y = startParamY + dy; wm.updateViewLayout(this, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) showPanel()
                }
                true
            }
        }
        bubble = v
        wm.addView(v, lp)
    }

    private fun showPanel() {
        if (panel != null) return
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_BLUR_BEHIND or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 31) lp.blurBehindRadius = 40
        val p = AuraPanelView(this) { hidePanel() }
        panel = p
        wm.addView(p, lp)
    }

    private fun hidePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    override fun onDestroy() {
        MusicState.listeners.remove(tint)
        hidePanel()
        bubble?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
