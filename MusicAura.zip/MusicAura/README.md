# Music Aura

Re-themes a glass, 3D "control center" panel to the album art of whatever song is playing (Spotify, YouTube, any player).

## Build
1. Open this folder in Android Studio (Koala or newer), let Gradle sync.
2. Plug in your Oppo (USB debugging on), press Run.

## First run
1. Allow notification access  2. Allow display over other apps  3. Start Music Aura.
Oppo/ColorOS: set Battery to "Unrestricted" and lock the app in Recents so it isn't killed.
A colored bubble appears on the right edge (drag it up/down). Tap it while a song plays.

## Optional: tint the real system accent too (experimental)
adb shell pm grant com.musicaura android.permission.WRITE_SECURE_SETTINGS
Then switch on "Also tint system accent" in the app. ColorOS may ignore it.

## Tweaks
- Tilt feels inverted: flip signs in AuraPanelView.onSensorChanged.
- Colors: ColorEngine.extract.

## v2 additions
- Vinyl: album art spins like a record while playing. Tap the disc to switch vinyl / square.
- Visualizer: real audio bars via the Visualizer API (needs the Microphone permission prompt, step 3).
  If ColorOS or the player blocks it, bars switch to an animated simulation.
- Lock screen: switch on "Tint LOCK SCREEN wallpaper". Replaces your lock wallpaper with a song-colored one,
  so note it overwrites your current lock wallpaper. ColorOS lock-screen magazine features may override it.

## v3: music video background
1. Get a free YouTube Data API v3 key: console.cloud.google.com -> new project -> enable "YouTube Data API v3" -> Credentials -> API key.
2. In the app: paste the key, tap Save API key, switch on "Play the song's music video...".
3. Play a song anywhere, open the panel: the music video plays muted behind the glass card, synced to the song position.
Notes: needs internet; some videos block embedding; sync is approximate (video intros differ from the audio track).
